package com.helloworld;

public class Nova {
    public static void sayGoodNight
}
