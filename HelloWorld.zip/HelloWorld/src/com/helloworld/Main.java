package com.helloworld;

import java.util.Date;

public class Main {

    public static void main(String[] args) {
      String letter = "A";
      boolean eligible = true;
      int age = 300;
      char chooseLetter = 'A';
      float price = 10.99F;
      Date now = new Date();

     public static void


    }

}


